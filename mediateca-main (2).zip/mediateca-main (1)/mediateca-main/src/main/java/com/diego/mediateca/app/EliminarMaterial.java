package com.diego.mediateca.app;

import com.diego.mediateca.db.MaterialDAO;
import java.sql.SQLException;
import java.util.Scanner;

public class EliminarMaterial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MaterialDAO materialDAO = new MaterialDAO();
        
        System.out.print("Ingrese el ID del material a eliminar (ej: LIB001): ");
        String id = scanner.nextLine().trim().toUpperCase();
        
        try {
            boolean eliminado = materialDAO.eliminarMaterial(id);
            
            if (eliminado) {
                System.out.println(" Material eliminado correctamente: " + id);
            } else {
                System.out.println(" No se pudo eliminar el material: " + id);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        scanner.close();
    }
}


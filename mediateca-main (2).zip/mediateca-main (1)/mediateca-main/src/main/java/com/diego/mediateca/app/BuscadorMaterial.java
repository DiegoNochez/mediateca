package com.diego.mediateca.app;

import com.diego.mediateca.db.MaterialDAO;
import com.diego.mediateca.domain.Material;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class BuscadorMaterial {
    private final MaterialDAO materialDAO;
    private final Scanner scanner;

    public BuscadorMaterial() {
        this.materialDAO = new MaterialDAO();
        this.scanner = new Scanner(System.in);
    }

    // ==================== MÉTODOS PÚBLICOS DE BÚSQUEDA ====================

    /**
     * Busca un material por su ID interno
     */
    public void buscarPorId() {
        System.out.print("Ingrese el ID interno (ej: LIB001, CDA001, DVD001): ");
        String id = scanner.nextLine().trim().toUpperCase();
        
        try {
            Optional<Material> material = materialDAO.buscarPorId(id);
            
            if (material.isPresent()) {
                System.out.println("\n MATERIAL ENCONTRADO:");
                System.out.println(material.get());
            } else {
                System.out.println(" No se encontró material con ID: " + id);
            }
        } catch (SQLException e) {
            System.out.println(" Error de base de datos: " + e.getMessage());
        }
    }

    /**
     * Busca materiales por título (búsqueda parcial)
     */
    public void buscarPorTitulo() {
        System.out.print("Ingrese el título a buscar: ");
        String titulo = scanner.nextLine().trim();
        
        try {
            List<Material> resultados = materialDAO.buscarPorTitulo(titulo);
            mostrarResultadosBusqueda(resultados, "título: '" + titulo + "'");
        } catch (SQLException e) {
            System.out.println("❌ Error de base de datos: " + e.getMessage());
        }
    }

    /**
     * Busca materiales por autor/director/artista
     */
    public void buscarPorAutor() {
        System.out.print("Ingrese el autor/director/artista a buscar: ");
        String autor = scanner.nextLine().trim();
        
        try {
            List<Material> resultados = materialDAO.buscarPorAutor(autor);
            mostrarResultadosBusqueda(resultados, "autor: '" + autor + "'");
        } catch (SQLException e) {
            System.out.println(" Error de base de datos: " + e.getMessage());
        }
    }

    /**
     * Lista todos los materiales disponibles
     */
    public void listarTodosLosMateriales() {
        try {
            List<Material> materiales = materialDAO.listarTodosLosMateriales();
            
            if (materiales.isEmpty()) {
                System.out.println("No hay materiales en la mediateca");
            } else {
                System.out.println("\n " + materiales.size() + " MATERIAL(ES) EN LA MEDIATECA:");
                for (int i = 0; i < materiales.size(); i++) {
                    System.out.println((i + 1) + ". " + materiales.get(i));
                }
            }
        } catch (SQLException e) {
            System.out.println(" Error de base de datos: " + e.getMessage());
        }
    }

    // ==================== MÉTODOS AUXILIARES PRIVADOS ====================

    private void mostrarResultadosBusqueda(List<Material> resultados, String criterio) {
        if (resultados.isEmpty()) {
            System.out.println(" No se encontraron materiales con " + criterio);
        } else {
            System.out.println("\n " + resultados.size() + " MATERIAL(ES) ENCONTRADO(S) con " + criterio + ":");
            for (int i = 0; i < resultados.size(); i++) {
                System.out.println((i + 1) + ". " + resultados.get(i));
            }
        }
    }

    public void cerrarScanner() {
        scanner.close();
    }
}
